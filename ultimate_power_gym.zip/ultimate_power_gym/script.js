
"use strict";

/* ==========================================
   ULTIMATE POWER FITNESS
   Interactive JavaScript
========================================== */

document.addEventListener("DOMContentLoaded", () => {

    const $ = (selector, parent = document) =>
        parent.querySelector(selector);

    const $$ = (selector, parent = document) =>
        [...parent.querySelectorAll(selector)];


    // ======================================
    // PRELOADER
    // ======================================

    const preloader = $("#preloader");

    const hidePreloader = () => {
        if (preloader) {
            preloader.classList.add("hide");
        }
    };

    window.addEventListener("load", hidePreloader, { once: true });

    // Fallback for slow-loading external resources.
    setTimeout(hidePreloader, 2500);


    // ======================================
    // MOBILE NAVIGATION
    // ======================================

    const menuToggle = $("#menuToggle");
    const navLinks = $("#navLinks");
    const navItems = $$(".nav-link, .nav-cta");

    function closeMenu() {
        navLinks?.classList.remove("open");
        document.body.classList.remove("menu-open");

        menuToggle?.setAttribute("aria-expanded", "false");

        if (menuToggle) {
            menuToggle.innerHTML =
                '<i class="fa-solid fa-bars"></i>';
            menuToggle.setAttribute("aria-label", "Open navigation");
        }
    }

    menuToggle?.addEventListener("click", () => {

        const isOpen = navLinks.classList.toggle("open");

        document.body.classList.toggle("menu-open", isOpen);

        menuToggle.setAttribute("aria-expanded", String(isOpen));

        menuToggle.innerHTML = isOpen
            ? '<i class="fa-solid fa-xmark"></i>'
            : '<i class="fa-solid fa-bars"></i>';

        menuToggle.setAttribute(
            "aria-label",
            isOpen ? "Close navigation" : "Open navigation"
        );

    });

    navItems.forEach(link => {
        link.addEventListener("click", closeMenu);
    });

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") closeMenu();
    });


    // ======================================
    // HEADER SCROLL EFFECT
    // ======================================

    const header = $("#header");
    const backToTop = $("#backToTop");

    function handleScroll() {

        const scrollPosition = window.scrollY;

        header?.classList.toggle("scrolled", scrollPosition > 50);

        backToTop?.classList.toggle("show", scrollPosition > 500);

    }

    window.addEventListener("scroll", handleScroll, {
        passive: true
    });

    handleScroll();


    // ======================================
    // BACK TO TOP
    // ======================================

    backToTop?.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });


    // ======================================
    // SCROLL REVEAL ANIMATIONS
    // ======================================

    const revealElements = $$(".reveal");

    if ("IntersectionObserver" in window) {

        const revealObserver = new IntersectionObserver(
            (entries, observer) => {

                entries.forEach(entry => {

                    if (entry.isIntersecting) {

                        entry.target.classList.add("visible");

                        observer.unobserve(entry.target);

                    }

                });

            },
            {
                threshold: 0.12,
                rootMargin: "0px 0px -40px 0px"
            }
        );

        revealElements.forEach(element => {
            revealObserver.observe(element);
        });

    } else {

        revealElements.forEach(element => {
            element.classList.add("visible");
        });

    }


    // ======================================
    // ANIMATED COUNTERS
    // ======================================

    const counters = $$(".counter");

    function animateCounter(element) {

        const target = Number(element.dataset.target);

        if (!Number.isFinite(target) || target < 0) return;

        const duration = 1800;
        const startTime = performance.now();

        function updateCounter(currentTime) {

            const elapsed = currentTime - startTime;

            const progress = Math.min(elapsed / duration, 1);

            // Ease-out animation
            const eased = 1 - Math.pow(1 - progress, 4);

            const current = Math.floor(target * eased);

            element.textContent = current.toLocaleString("en-IN");

            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = target.toLocaleString("en-IN");
            }

        }

        requestAnimationFrame(updateCounter);

    }

    if ("IntersectionObserver" in window) {

        const counterObserver = new IntersectionObserver(
            (entries, observer) => {

                entries.forEach(entry => {

                    if (entry.isIntersecting) {

                        animateCounter(entry.target);

                        observer.unobserve(entry.target);

                    }

                });

            },
            { threshold: 0.6 }
        );

        counters.forEach(counter => {
            counterObserver.observe(counter);
        });

    } else {

        counters.forEach(counter => {
            animateCounter(counter);
        });

    }


    // ======================================
    // ACTIVE NAVIGATION ON SCROLL
    // ======================================

    const sections = $$("main section[id]");

    if ("IntersectionObserver" in window) {

        const sectionObserver = new IntersectionObserver(
            entries => {

                entries.forEach(entry => {

                    if (!entry.isIntersecting) return;

                    const sectionId = entry.target.id;

                    $$(".nav-link").forEach(link => {

                        const isActive =
                            link.getAttribute("href") === `#${sectionId}`;

                        link.classList.toggle("active", isActive);

                    });

                });

            },
            {
                rootMargin: "-35% 0px -55% 0px"
            }
        );

        sections.forEach(section => {
            sectionObserver.observe(section);
        });

    }


    // ======================================
    // 3D CARD HOVER EFFECT
    // ======================================

    const tiltCards = $$(".program-card");

    const supportsHover = window.matchMedia(
        "(hover: hover) and (pointer: fine)"
    ).matches;

    if (supportsHover && !window.matchMedia(
        "(prefers-reduced-motion: reduce)"
    ).matches) {

        tiltCards.forEach(card => {

            card.addEventListener("pointermove", event => {

                const rect = card.getBoundingClientRect();

                const x = event.clientX - rect.left;
                const y = event.clientY - rect.top;

                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateX = ((y - centerY) / centerY) * -5;
                const rotateY = ((x - centerX) / centerX) * 5;

                card.style.transform =
                    `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;

            });

            card.addEventListener("pointerleave", () => {

                card.style.transform = "";

            });

        });

    }


    // ======================================
    // HERO 3D MOUSE EFFECT
    // ======================================

    const heroImage = $(".hero-image-wrap");

    if (
        heroImage &&
        supportsHover &&
        !window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {

        const heroVisual = $(".hero-visual");

        heroVisual?.addEventListener("pointermove", event => {

            const rect = heroVisual.getBoundingClientRect();

            const x = (event.clientX - rect.left) / rect.width - 0.5;
            const y = (event.clientY - rect.top) / rect.height - 0.5;

            heroImage.style.transform =
                `rotateY(${-x * 10}deg) rotateX(${y * 8}deg)`;

        });

        heroVisual?.addEventListener("pointerleave", () => {

            heroImage.style.transform = "";

        });

    }


    // ======================================
    // CONTACT FORM VALIDATION
    // ======================================

    const contactForm = $("#contactForm");
    const formStatus = $("#formStatus");

    contactForm?.addEventListener("submit", event => {

        event.preventDefault();

        if (!contactForm.checkValidity()) {

            contactForm.reportValidity();

            return;

        }

        const formData = new FormData(contactForm);

        const name = String(formData.get("name") || "").trim();
        const phone = String(formData.get("phone") || "").trim();
        const email = String(formData.get("email") || "").trim();

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        const phonePattern =
            /^\+?[0-9\s()-]{7,15}$/;

        if (name.length < 2) {

            showFormMessage(
                "Please enter a valid name.",
                "error"
            );

            return;

        }

        if (!phonePattern.test(phone)) {

            showFormMessage(
                "Please enter a valid phone number.",
                "error"
            );

            return;

        }

        if (!emailPattern.test(email)) {

            showFormMessage(
                "Please enter a valid email address.",
                "error"
            );

            return;

        }

        showFormMessage(
            "Your details are valid! Connect a PHP/API backend to securely receive enquiries.",
            "success"
        );

        // This is a frontend demonstration.
        // No information is sent or stored.

        console.log("Validated enquiry fields:", {
            name,
            phone,
            email,
            interest: formData.get("interest")
        });

    });


    function showFormMessage(message, type) {

        if (!formStatus) return;

        formStatus.textContent = message;

        formStatus.style.color =
            type === "success" ? "#4ade80" : "#ff5555";

    }


    // ======================================
    // CURRENT YEAR
    // ======================================

    const yearElement = $("#year");

    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }


    // ======================================
    // IMAGE LOADING FALLBACK
    // ======================================

    $$("img").forEach(img => {

        img.addEventListener("error", () => {

            img.style.opacity = "0.35";

        }, { once: true });

    });


    console.log("Ultimate Power Fitness website initialized.");

});
