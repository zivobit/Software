# Ultimate Power — Static Gym Website

A responsive, single-page gym website built with HTML, CSS and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive black/red visual design
- `script.js` — mobile navigation, reveal animations, enquiry validation and contact configuration

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. For local development, you can also use VS Code Live Server or PHP's built-in server.

## Before publishing — important setup
Open `script.js` and update `GYM_CONFIG` with your real details:
- `phone`
- `whatsapp` (international digits only, including country code)
- `address`
- `openingHours`
- `email` (optional)
- `instagram`
- `facebook`

Also update the membership plans, prices, opening hours, location and any claims in `index.html` to match your actual gym. The current plan prices and contact details are deliberately not invented.

## Enquiry form
The form validates user input in the browser. It does not store or transmit enquiries on its own.
- If `whatsapp` is configured, it prepares an enquiry in WhatsApp and the visitor must press Send.
- Otherwise, if `email` is configured, it opens the visitor's email app with a prepared message.
- For reliable business enquiries, connect a secure backend or reputable form/CRM service. Never put private API keys or database credentials in front-end JavaScript.

## Images and external assets
The site uses remotely hosted Unsplash images and CDN-hosted Font Awesome icons, plus Google Fonts. An internet connection is required for these assets. Replace image URLs with your own gym photography for the most authentic presentation.

## Notes
- The sample gym name is Ultimate Power.
- The location, phone, hours, prices, social profiles and member statistics are not fabricated.
- The BMI calculator and member portal are not included; this is a polished static marketing website.
